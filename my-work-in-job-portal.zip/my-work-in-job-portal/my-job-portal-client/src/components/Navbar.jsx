import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { FaBarsStaggered, FaXmark } from "react-icons/fa6";

const Navbar = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const handleMenuToggle = () => {
        setIsMenuOpen(!isMenuOpen);
    };
    const navItems = [
        { path: "/", title: "Start a search" },
        { path: "/my-job", title: "My Jobs" },
        { path: "/salary", title: "Salary Estimated" },
        { path: "/post-job", title: "Post A Job" },
        { path: "/About", title: "About" }
    ]
    return (
        <header className="max-w-screen-2xl container mx-auto xl:px-24 px-4">
            <nav className="flex justify-between items-center py-6">
                <a href='/'
                    className='flex items-center gap-2 text-2x1 text-black'>
                    <svg xmlns="http://www.w3.org/2000/svg" width="29" height="30" viewBox="0 0 29 30" fill="none" >
                        <circle cx="12.0143" cy="12.5143" r=" 12.0143" fill="#3575E2" fillOpacity="0.4" />
                        <circle cx="16.9857" cy="17.9857" r=" 12.0143" fill="#3575E2" />
                    </svg>
                    <span>JobPortal</span>
                </a>
                {/* {nav  items dor large deivces} */}

                <ul className=' hidden md:flex gap-12'>
                    {
                        navItems.map(({ path, title }) => (
                            <li key={path} className=' text-primary text-base'>
                                <NavLink to={path} className={({ isActive }) => isActive ? "active" : ""}>
                                    {title}
                                </NavLink>
                            </li>))
                    }
                </ul>
                {/* {signup and login botton} */}
                <div className="text-base text-primary  font-medium space-x-5 lg:block">
                    <Link to="/login" className="py-2 px-5 border rounded">Log in</Link>
                    <Link to="/sign-up" className="py-2 px-5 border rounded bg-blue text-white">sign up</Link>

                    {/* <link to="/login"> login</link> */}
                </div>

                {/* {mobile Menu} */}
                <div className="md:hidden block">
                    <button onClick={handleMenuToggle}>
                        {
                            isMenuOpen ? <FaXmark className=" w-5 h-5 text-primary" /> : <FaBarsStaggered className=" w-5 h-5 text-primary" />
                        }

                    </button>


                </div>
            </nav>
            {/* { navitems for mobile} */}
            <div className={`px-4 bg-black py-5 rounded-sm ${isMenuOpen ? "" : "hidden"}`}>
                <ul>{
                    navItems.map(({ path, title }) => (
                        <li key={path} className=' text-white text-base first:text-white py-1'>
                            <NavLink to={path} className={({ isActive }) => isActive ? "active" : ""}>
                                {title}
                            </NavLink>
                        </li>))}

                    <li className="text-white py-1 ">
                        <Link to="/login" >Log in</Link>
                    </li>
                    <li className="text-white py-1 ">
                        <Link to="/sign-up">sign up</Link>
                    </li>
                </ul>
            </div>
        </header>
    )
}

export default Navbar