import React from 'react'

const Footerbar = () => {

    const currentYear = new Date().getFullYear();
    return (
        <footer className=" max-w-screen-2xl container mx-auto xl:px-24 px-4 rounded-lg shadow m-4 bg-gray-500">
            <div className=" flex justify-between items-center py-6">

                <span className="text-sm text-black sm:text-center">
                 &copy; {currentYear} <a href="/" className="hover:underline">Job Portal™</a>. All Rights Reserved.
                </span>
                <ul className="flex flex-wrap items-center mt-3 text-sm font-medium text-black sm:mt-0">
                    <li>
                        <a href="#" className="hover:underline me-4 md:me-6">About</a>
                    </li>
                    <li>
                        <a href="#" className="hover:underline me-4 md:me-6">Privacy Policy</a>
                    </li>
                    <li>
                        <a href="#" className="hover:underline me-4 md:me-6">Licensing</a>
                    </li>
                    <li>
                        <a href="#" className="hover:underline">Contact</a>
                    </li>
                </ul>
            </div>
        </footer>
    )
}

export default Footerbar