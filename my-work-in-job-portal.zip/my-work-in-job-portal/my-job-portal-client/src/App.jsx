

import { Outlet } from 'react-router-dom'
import './App.css'
import Navbar from './components/Navbar'
import Footerbar from "./components/Footerbar";

function App() {


  return (
    <>
      <Navbar />
      <Outlet />
      <Footerbar />

    </>
  )
}

export default App
