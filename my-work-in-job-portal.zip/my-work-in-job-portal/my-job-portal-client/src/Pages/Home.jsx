import React from 'react'

const Home = () => {
  return (
    <div className="text-blue "> Home page</div>
  )
}

export default Home