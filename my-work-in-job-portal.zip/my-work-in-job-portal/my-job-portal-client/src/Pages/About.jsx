import React from 'react'

const About = () => {
  return (
    <div>THIS IS OUR PAGE ABOUT PORTAL JOBS</div>
  )
}

export default About